package com.company;

/*
Name: Kevin Khamfong
Email: kevink4@umbc.edu
 */

public class FunctionManager {
    private static final String[] functions = new String[] {"Pet Tracker", "Exit"};

    public static String[] getFunctions() {
      return functions;
    }

}
